public interface UserBookBuyHistory {
    public static String TABLE_BOOK_BUYING_HISTORY = "buying_history";
	
	public static String COLUMN_NAME = "username";
	public static String COLUMN_DATE = "buying_date";
    public static String COLUMN_BOOKLIST="book_list";
	public static String COLUMN_TOTAL_PRICE = "total_price";
	public static String COLUMN_QUANTITY = "quantity";
}

